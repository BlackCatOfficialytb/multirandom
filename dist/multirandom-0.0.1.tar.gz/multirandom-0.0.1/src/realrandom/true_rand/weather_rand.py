# rand via openweather api and openmeteo api
print("coming soon")