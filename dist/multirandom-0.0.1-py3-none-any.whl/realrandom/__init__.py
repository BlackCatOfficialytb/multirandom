import true_rand
import virt_rand
import hash_rand