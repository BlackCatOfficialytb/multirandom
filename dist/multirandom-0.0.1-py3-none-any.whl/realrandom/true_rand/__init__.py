import rand_via_clicks
import rand_using_online_api
# import weather_rand