import original_random
import sha_rand as sha_random